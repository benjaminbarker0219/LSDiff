import os
from glob import glob
from PIL import Image
import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms

class CustomDataset(Dataset):
    def __init__(self, arg,data_path, transform=None):
        print("Loading data from directory:", data_path)

        # 获取 image 文件列表（假设图片格式为 .jpg）
        self.image_list = sorted(glob(os.path.join(data_path, "image_test/*.png")))
        self.mask_list = [img_path.replace("image_test/", "mask_test/").replace(".png", ".png") for img_path in self.image_list]

        self.transform = transform

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        """Get the images"""
        img_path = self.image_list[index]
        msk_path = self.mask_list[index]

        img = Image.open(img_path).convert('L')  # 读取 RGB 图片
        mask = Image.open(msk_path).convert('L')   # 读取灰度掩码

        if self.transform:
            state = torch.get_rng_state()
            img = self.transform(img)
            torch.set_rng_state(state)
            mask = self.transform(mask)

        return img, mask, img_path  # 返回图片、掩码、文件路径
# import os
# from glob import glob
# from PIL import Image
# import torch
# from torch.utils.data import Dataset
# import torchvision.transforms as transforms

# class CustomDataset(Dataset):
#     def __init__(self, arg,data_path, transform=None):
#         print("Loading data from directory:", data_path)

#         # 获取 image 文件列表（假设图片格式为 .jpg）
#         self.image_list = sorted(glob(os.path.join(data_path, "images/*.jpg")))
#         self.mask_list = [img_path.replace("images/", "masks/").replace(".jpg", "_mask.jpg") for img_path in self.image_list]

#         self.transform = transform

#     def __len__(self):
#         return len(self.image_list)

#     def __getitem__(self, index):
#         """Get the images"""
#         img_path = self.image_list[index]
#         msk_path = self.mask_list[index]

#         img = Image.open(img_path).convert('RGB')  # 读取 RGB 图片
#         mask = Image.open(msk_path).convert('L')   # 读取灰度掩码

#         if self.transform:
#             state = torch.get_rng_state()
#             img = self.transform(img)
#             torch.set_rng_state(state)
#             mask = self.transform(mask)

#         return img, mask, img_path  # 返回图片、掩码、文件路径